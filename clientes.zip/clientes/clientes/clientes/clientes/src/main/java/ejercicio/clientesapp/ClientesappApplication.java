package ejercicio.clientesapp;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;


@Entity
public class ClientesappApplication {
	@Id
	@GeneratedValue
	private Long idcliente;
	private String nombrecliente;
	private String telefonocliente;
	private String nitcliente;

	public ClientesappApplication() {
	}

	public ClientesappApplication(String nombrecliente, String telefonocliente, String nitcliente) {
		this.nombrecliente = nombrecliente;
		this.telefonocliente = telefonocliente;
		this.nitcliente = nitcliente;
	}

	public void setId(Long idcliente) {
		this.idcliente = idcliente;
	}

	public Long getId() {
		return idcliente;
	}

	public String getnombrecliente() {
		return nombrecliente;
	}

	public void setnombrecliente() {
		this.nombrecliente = nombrecliente;
	}

	public String gettelefonocliente() {
		return telefonocliente;
	}

	public void settelefonocliente() {
		this.telefonocliente = telefonocliente;
	}

	public String getnitcliente() {
		return nitcliente;
	}

	public void setnitcliente() {
		this.nitcliente = nitcliente;
	}

	@Override
	public String toString() {
		return "cliente{" + "idcliente=" + idcliente + ", nombrecliente='" + nombrecliente + '\'' +
				", telefonocliente='" + telefonocliente + '\'' + ", nitcliente='" + nitcliente + '\'' +
				'}';
	}


	private void insertFourclientes(clientesrepositorio repository) {
		repository.save(new ClientesappApplication("Raul Gonzalez", "77558874", "258745k"));
		repository.save(new ClientesappApplication("Fernando", "587456978", "2589625"));
		repository.save(new ClientesappApplication("Rud VanNis", "25874563", "258745"));
		repository.save(new ClientesappApplication("Iker Cas", "236547896", "2587456k"));
	}

	@Bean
	public CommandLineRunner run(clientesrepositorio repository) {
		return (args) -> {
			insertFourclientes(repository);
			System.out.println(repository.findAll());
		};

	}
}
