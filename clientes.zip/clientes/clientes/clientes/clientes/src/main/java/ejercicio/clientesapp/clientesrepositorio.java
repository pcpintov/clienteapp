package ejercicio.clientesapp;

import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface clientesrepositorio extends CrudRepository<ClientesappApplication, Long> {
    List<ClientesappApplication> findclientesbyLastNameContaining(String str);
}
